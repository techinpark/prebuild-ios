#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "BadgeLabel.h"
#import "BadgeTableViewCell.h"

FOUNDATION_EXPORT double BadgeLabelVersionNumber;
FOUNDATION_EXPORT const unsigned char BadgeLabelVersionString[];

