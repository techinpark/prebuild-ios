//  The MIT License (MIT)
//
//  Copyright (c) 2015 - present Ermal Kaleci
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all
//  copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.
//

#import <UIKit/UIKit.h>
#import "CarbonTabSwipeSegmentedControl.h"


NS_ASSUME_NONNULL_BEGIN

@interface CarbonTabSwipeScrollView : UIScrollView

/**
 *  Custimized segmented control without tint color and divider image
 */
@property(nonatomic, strong, readonly) CarbonTabSwipeSegmentedControl *carbonSegmentedControl;

/**
 *  Create CarbonTabScrollView with items. Items can be NSString or UIImage like
 *  creating a SegmentedControl. ScrollView content size is equal to
 *  SegmentedControl width.
 *
 *  @param items Array of segment titles or images
 *
 *  @return CarbonTabSwipeScrollView that contains CarbonTabSwipeSegmentedControl
 */
- (instancetype)initWithItems:(nullable NSArray *)items;

/**
 *  Add items to CarbonTabScrollView. Items can be NSString or UIImage like
 *  creating a SegmentedControl. ScrollView content size is equal to
 *  SegmentedControl width.
 *
 *  @param items Array of segment titles or images
 */
- (void)setItems:(nullable NSArray *)items;

NS_ASSUME_NONNULL_END

@end
