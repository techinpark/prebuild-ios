//
//  Created by Nigel Timothy Barber (@mindbrix) on 13/04/2012.
//

#import "NSString+MD5.h"
 
@interface NSString(MD5)
 
- (NSString *)MD5;
 
@end
